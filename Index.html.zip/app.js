(function () {
  'use strict';
  var WA = '2349166116812';

  /* ===== EASY TO UPDATE: add future trade videos here (newest first) =====
     id = the part after youtube.com/shorts/ (or youtu.be/) in the link */
  var TRADE_VIDEOS = [
    { id: 'M7zwY2m5faU', title: 'Latest CRT Sniper trade breakdown', note: 'Educational walkthrough of an actual CRT setup.' }
  ];

  var LESSONS = [
    { t: 'CRT fundamentals', p: ['CRT stands for Candle Range Theory. It treats the high and low of one candle as a map for what price may do next.', 'A common model uses three candles: accumulation (the range candle), manipulation (price pushes beyond one side of the range) and distribution (price moves back through the range).', 'This is a framework for reading price, not a rule. Sometimes it works and sometimes it fails.'], k: 'Mark the range first. Decide what you would do before price gets there.' },
    { t: 'Candle ranges', p: ['A candle range runs from its high to its low. Draw both lines, then add the 50% midpoint halfway between them.', 'Many students use a higher timeframe candle, such as the 4-hour, to set the range, then study smaller timeframes for detail.', 'The diagram below shows a range with its High, Low and 50% midpoint.'], k: 'High, Low and the 50% midpoint are the three lines you mark on every range.', d: true },
    { t: 'Liquidity', p: ['Liquidity is where many orders rest, usually stop orders just above recent highs and just below recent lows.', 'Price often moves beyond those levels briefly. This is called a sweep. After a sweep, price may reverse, but it may also keep going.', 'A sweep is a clue, never a guarantee.'], k: 'A sweep is a reason to pay attention, not a reason to enter.' },
    { t: 'Market structure', p: ['Structure is the pattern of highs and lows. Higher highs and higher lows describe an uptrend. Lower highs and lower lows describe a downtrend.', 'Check the bigger picture first. A setup that fits the larger direction is usually easier to read than one that fights it.', 'When structure is unclear, skipping the trade is a valid decision.'], k: 'Read the bigger direction before you look for a setup.' },
    { t: 'Entries', p: ['In CRT, many traders wait for price to sweep one side of the range and then close back inside it. Only then do they look for an entry.', 'Entry ideas include a smaller timeframe shift in structure, or a pullback toward the 50% midpoint.', 'Always decide your stop loss and target before you place the order.'], k: 'Patience matters more than speed. Fewer, clearer trades are easier to manage.' },
    { t: 'Confirmations', p: ['Confirmation means waiting for extra evidence. Examples include a candle that closes back inside the range or a shift in structure on a smaller timeframe.', 'A wick alone is weaker evidence than a close. Waiting for a close can mean a later entry, but it filters some false moves.', 'No confirmation removes risk. It only helps you be more selective.'], k: 'Confirmation improves selectivity. It does not remove risk.' },
    { t: 'Risk management', p: ['Decide how much you are willing to lose before every trade. Many educators suggest risking a small percentage of the account, such as 1% or less.', 'Place the stop loss where the idea is proven wrong, for example beyond the sweep. Then size the position so that a stop-out costs only the amount you chose.', 'Losing trades are normal. Protecting your account lets you keep learning.'], k: 'Size the trade from the stop distance, not from how confident you feel.' },
    { t: 'Trade execution', p: ['Use a simple checklist: 1) Mark the range. 2) Wait for a sweep. 3) Wait for confirmation. 4) Plan entry, stop and target. 5) Size the position. 6) Execute and leave the plan alone.', 'Record every trade in a journal, including the ones you skipped, and review it weekly.', 'Practise on a demo account first. Nothing here guarantees profit.'], k: 'Plan, execute, journal, review. Repeat.' }
  ];

  var QUIZ = [
    { q: 'What does CRT stand for?', o: ['Candle Range Theory', 'Currency Risk Trading', 'Chart Reversal Technique'], a: 0, e: 'CRT is Candle Range Theory.' },
    { q: 'Which three lines do you mark on a candle range?', o: ['Open, Close and Volume', 'High, Low and the 50% midpoint', 'Support, Resistance and Trend'], a: 1, e: 'High, Low and the 50% midpoint.' },
    { q: 'What is a liquidity sweep?', o: ['Price briefly moves beyond a recent high or low', 'A broker closing your trade', 'A new indicator signal'], a: 0, e: 'Price pushes past a level where orders rest, then may reverse or continue.' },
    { q: 'Why check the bigger structure first?', o: ['It guarantees a win', 'It gives context for whether a setup fits the larger direction', 'It removes the need for a stop loss'], a: 1, e: 'Context helps, but nothing guarantees a win.' },
    { q: 'In CRT, what do many traders wait for before looking for an entry?', o: ['A sweep and a close back inside the range', 'Any green candle', 'A news headline'], a: 0, e: 'A sweep followed by a close back inside the range.' },
    { q: 'What does confirmation do?', o: ['Removes all risk', 'Guarantees profit', 'Helps you be more selective'], a: 2, e: 'It improves selectivity. Risk remains.' },
    { q: 'Where is a sensible place for a stop loss?', o: ['Wherever feels comfortable', 'Where the trade idea is proven wrong', 'As far away as possible'], a: 1, e: 'Place it where the idea is invalid, then size the position to match.' },
    { q: 'What should you do after every trade?', o: ['Delete the chart', 'Record it in a journal and review it', 'Double the next position'], a: 1, e: 'Journaling and review build consistency.' }
  ];

  function $(s, r) { return (r || document).querySelector(s); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  /* menu */
  var burger = $('#burger'), menu = $('#menu');
  if (burger && menu) {
    burger.addEventListener('click', function () {
      var o = menu.classList.toggle('open');
      burger.setAttribute('aria-expanded', o ? 'true' : 'false');
    });
    menu.addEventListener('click', function (e) {
      if (e.target.tagName === 'A') { menu.classList.remove('open'); burger.setAttribute('aria-expanded', 'false'); }
    });
  }

  /* trade video */
  var box = $('#videoBox');
  if (box && TRADE_VIDEOS.length) {
    var list = $('#videoList'), vt = $('#videoTitle'), vn = $('#videoNote');
    var show = function (i) {
      var v = TRADE_VIDEOS[i];
      box.innerHTML = '<iframe src="https://www.youtube.com/embed/' + encodeURIComponent(v.id) + '?rel=0&playsinline=1" title="' + esc(v.title) + '" loading="lazy" allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>';
      if (vt) vt.textContent = v.title;
      if (vn) vn.textContent = v.note || '';
      if (list) Array.prototype.forEach.call(list.children, function (b, j) { b.setAttribute('aria-pressed', j === i ? 'true' : 'false'); });
    };
    if (list && TRADE_VIDEOS.length > 1) {
      TRADE_VIDEOS.forEach(function (v, i) {
        var b = document.createElement('button');
        b.type = 'button'; b.className = 'chip'; b.textContent = 'Video ' + (i + 1);
        b.addEventListener('click', function () { show(i); });
        list.appendChild(b);
      });
    }
    show(0);
  }

  /* lessons */
  var L = $('#lessonBody');
  if (L) {
    var cur = 0, nav = $('#lessonNav'), prev = $('#prevBtn'), next = $('#nextBtn'), bar = $('#progBar'), cnt = $('#lessonCount');
    var tpl = $('#rangeDiagram');
    LESSONS.forEach(function (l, i) {
      var b = document.createElement('button');
      b.type = 'button'; b.className = 'chip'; b.textContent = String(i + 1);
      b.setAttribute('aria-label', 'Lesson ' + (i + 1) + ': ' + l.t);
      b.addEventListener('click', function () { go(i); });
      nav.appendChild(b);
    });
    var go = function (i) {
      cur = Math.max(0, Math.min(LESSONS.length - 1, i));
      var l = LESSONS[cur];
      L.innerHTML = '<h3>Lesson ' + (cur + 1) + ': ' + esc(l.t) + '</h3>' + l.p.map(function (p) { return '<p>' + esc(p) + '</p>'; }).join('') + (l.d && tpl ? '<div class="diagram">' + tpl.innerHTML + '</div>' : '') + '<p class="key">' + esc(l.k) + '</p>';
      cnt.textContent = 'Lesson ' + (cur + 1) + ' of ' + LESSONS.length;
      bar.style.width = ((cur + 1) / LESSONS.length * 100) + '%';
      prev.disabled = cur === 0; next.disabled = cur === LESSONS.length - 1;
      Array.prototype.forEach.call(nav.children, function (b, j) { b.classList.toggle('on', j === cur); b.setAttribute('aria-pressed', j === cur ? 'true' : 'false'); });
    };
    prev.addEventListener('click', function () { go(cur - 1); });
    next.addEventListener('click', function () { go(cur + 1); });
    go(0);
  }

  /* quiz */
  var Q = $('#quizBody');
  if (Q) {
    var res = $('#quizResult'), render = function () {
      Q.innerHTML = QUIZ.map(function (x, i) {
        return '<div class="q" id="q' + i + '"><p>' + (i + 1) + '. ' + esc(x.q) + '</p>' + x.o.map(function (o, j) {
          return '<label><input type="radio" name="q' + i + '" value="' + j + '"><span>' + esc(o) + '</span></label>';
        }).join('') + '<p class="ex"></p></div>';
      }).join('');
      res.textContent = '';
    };
    render();
    $('#quizCheck').addEventListener('click', function () {
      var score = 0, answered = 0;
      QUIZ.forEach(function (x, i) {
        var sel = Q.querySelector('input[name="q' + i + '"]:checked'), el = $('#q' + i);
        el.className = 'q';
        if (!sel) return;
        answered++;
        var ok = Number(sel.value) === x.a;
        if (ok) score++;
        el.className = 'q ' + (ok ? 'ok' : 'bad');
        $('.ex', el).textContent = (ok ? 'Correct. ' : 'Not quite. ') + x.e;
      });
      if (answered < QUIZ.length) { res.textContent = 'Please answer all ' + QUIZ.length + ' questions first (' + answered + ' answered).'; return; }
      var m = score === 8 ? 'Excellent. You understand the basics well.' : score >= 6 ? 'Good work. Review the lessons for the ones you missed.' : score >= 4 ? 'A fair start. Go back through the lessons and try again.' : 'Take your time with the lessons, then retake the quiz.';
      res.textContent = 'Score: ' + score + ' / ' + QUIZ.length + '. ' + m;
    });
    $('#quizReset').addEventListener('click', render);
  }

  /* WhatsApp enrolment form */
  var f = $('#enrolForm');
  if (f) {
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      var n = f.elements.name.value.trim(), c = f.elements.course.value, m = f.elements.msg.value.trim(), er = $('#formErr');
      if (!n) { er.textContent = 'Please enter your name.'; f.elements.name.focus(); return; }
      if (!c) { er.textContent = 'Please choose a course.'; f.elements.course.focus(); return; }
      er.textContent = '';
      var t = 'Hello Ahmad, my name is ' + n + '. I want to enrol for: ' + c + '.' + (m ? ' ' + m : '');
      window.location.href = 'https://wa.me/' + WA + '?text=' + encodeURIComponent(t);
    });
  }

  /* hide any image that fails to load (no broken-image icons) */
  Array.prototype.forEach.call(document.querySelectorAll('figure img'), function (im) {
    im.addEventListener('error', function () { var fg = im.closest('figure'); if (fg) fg.hidden = true; });
  });
})();
